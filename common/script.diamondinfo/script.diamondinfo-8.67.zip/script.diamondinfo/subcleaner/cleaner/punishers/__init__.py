from .adjacency import punish_ad_adjacency
from .duplicate import punish_clone_blocks, move_duplicated
from .regex import punish_regex_matches
from .time import punish_quick_first_block, punish_short_duration
