import orion
total_providers['orion'] = orion.__all__
