__copyright__ = "Copyright (C) 2020 Nidhal Baccouri"


from externals.deeptranslator.cli import CLI


def main():
    CLI().run()


if __name__ == "__main__":
    main()
