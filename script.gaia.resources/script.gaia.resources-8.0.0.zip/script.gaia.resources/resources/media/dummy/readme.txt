This is dummy JSON data to test the compression algorithms with, in order to determine which algorithm is fastest.

Large: Stream data as stored in streams.db after scraping.
Medium: Episode metadata as stored in metadata.db.
