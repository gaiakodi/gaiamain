Language word lists used during stream validation, through tools.Word().
For each list, make the words lower case, filter out duplicates, and created a \n separated text file.

English: https://github.com/dwyl/english-words (words.txt)
